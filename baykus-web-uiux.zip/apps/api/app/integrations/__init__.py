"""External integrations (stubs)."""
