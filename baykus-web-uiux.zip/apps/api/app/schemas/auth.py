from pydantic import BaseModel, EmailStr, Field


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    username: EmailStr = Field(description="E-posta adresi")
    password: str


class UserOut(BaseModel):
    id: int
    email: str
    full_name: str
    is_active: bool
    roles: list[str]
    lock_mode: str = "Yönetici"

    model_config = {"from_attributes": True}
