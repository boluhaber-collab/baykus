import re
import unicodedata

import pandas as pd


DEFAULT_WAREHOUSE = "Ana Depo"

PRODUCT_COLUMNS = [
    "Ürün Adı",
    "Ürün Tipi",
    "BEDEN",
    "RENK",
    "Baskı",
    "Kategori",
    "Marka",
    "KDV%",
    "Alış Fiyatı",
    "Satış Fiyatı",
    "Stok Miktarı",
    "Birim",
    "Stok Durumu",
    "Stok Adedi",
    "Beden Seçenekleri",
    "Renk Seçenekleri",
    "Tedarikçi",
    "Fotoğraf",
    "Depo",
    "Not",
]

COLUMN_ALIASES = {
    "Ürün Türü": "Ürün Tipi",
    "Urun Tipi": "Ürün Tipi",
    "Urun Turu": "Ürün Tipi",
    "Product Type": "Ürün Tipi",
    "ÃœrÃ¼n AdÄ±": "Ürün Adı",
    "ÃƒÅ“rÃƒÂ¼n AdÃ„Â±": "Ürün Adı",
    "ÃƒÆ’Ã…â€œrÃƒÆ’Ã‚Â¼n AdÃƒâ€Ã‚Â±": "Ürün Adı",
    "Ürün": "Ürün Adı",
    "ÃœrÃ¼n": "Ürün Adı",
    "ÃƒÅ“rÃƒÂ¼n": "Ürün Adı",
    "ÃƒÆ’Ã…â€œrÃƒÆ’Ã‚Â¼n": "Ürün Adı",
    "Urun Adi": "Ürün Adı",
    "Urun": "Ürün Adı",
    "BaskÄ±": "Baskı",
    "BaskÃ„Â±": "Baskı",
    "BaskÃƒâ€Ã‚Â±": "Baskı",
    "AlÄ±ÅŸ FiyatÄ±": "Alış Fiyatı",
    "AlÃ„Â±Ã…Å¸ FiyatÃ„Â±": "Alış Fiyatı",
    "AlÃƒâ€Ã‚Â±Ãƒâ€¦Ã…Â¸ FiyatÃƒâ€Ã‚Â±": "Alış Fiyatı",
    "Alis Fiyati": "Alış Fiyatı",
    "Alis Fiyat": "Alış Fiyatı",
    "SatÄ±ÅŸ FiyatÄ±": "Satış Fiyatı",
    "SatÃ„Â±Ã…Å¸ FiyatÃ„Â±": "Satış Fiyatı",
    "SatÃƒâ€Ã‚Â±Ãƒâ€¦Ã…Â¸ FiyatÃƒâ€Ã‚Â±": "Satış Fiyatı",
    "Satis Fiyati": "Satış Fiyatı",
    "Satis Fiyat": "Satış Fiyatı",
    "Stok MiktarÄ±": "Stok Miktarı",
    "Stok MiktarÃ„Â±": "Stok Miktarı",
    "Stok MiktarÃƒâ€Ã‚Â±": "Stok Miktarı",
    "Stok": "Stok Miktarı",
    "Miktar": "Stok Miktarı",
    "Stok Miktari": "Stok Miktarı",
    "Stok Adeti": "Stok Adedi",
    "Beden SeÃ§enekleri": "Beden Seçenekleri",
    "Beden SeÃƒÂ§enekleri": "Beden Seçenekleri",
    "Beden SeÃƒÆ’Ã‚Â§enekleri": "Beden Seçenekleri",
    "Beden Secenekleri": "Beden Seçenekleri",
    "Renk SeÃ§enekleri": "Renk Seçenekleri",
    "Renk SeÃƒÂ§enekleri": "Renk Seçenekleri",
    "Renk SeÃƒÆ’Ã‚Â§enekleri": "Renk Seçenekleri",
    "Renk Secenekleri": "Renk Seçenekleri",
    "TedarikÃ§i": "Tedarikçi",
    "TedarikÃƒÂ§i": "Tedarikçi",
    "TedarikÃƒÆ’Ã‚Â§i": "Tedarikçi",
    "Tedarikci": "Tedarikçi",
    "FotoÄŸraf": "Fotoğraf",
    "FotoÃ„Å¸raf": "Fotoğraf",
    "FotoÃƒâ€Ã…Â¸raf": "Fotoğraf",
    "Fotograf": "Fotoğraf",
}


def clean_text(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    text = str(value).strip()
    return "" if text.casefold() in ("nan", "none", "nat", "null") else text


def normalize_text(value):
    text = re.sub(r"\s+", " ", clean_text(value)).casefold()
    text = text.translate(str.maketrans({
        "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u",
        "Ç": "c", "Ğ": "g", "İ": "i", "I": "i", "Ö": "o", "Ş": "s", "Ü": "u",
    })).replace("i̇", "i")
    text = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in text if not unicodedata.combining(ch))


def to_number(value, default=0):
    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    text = str(value).strip().replace("TL", "").replace("₺", "").replace("â‚º", "").replace(" ", "")
    if "," in text:
        text = text.replace(".", "").replace(",", ".")
    try:
        return float(text)
    except Exception:
        return default


def format_number_value(value):
    try:
        number = float(value)
    except Exception:
        return value
    if abs(number - round(number)) < 0.0000001:
        return int(round(number))
    return number


def _column_key(value):
    text = normalize_text(value).replace("ı", "i")
    text = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in text if not unicodedata.combining(ch))


def _merge_column_values(df, source_column, target_column):
    if source_column not in df.columns:
        return df
    if target_column not in df.columns:
        df[target_column] = df[source_column]
        return df
    empty_rows = df[target_column].apply(clean_text) == ""
    if empty_rows.any():
        df.loc[empty_rows, target_column] = df.loc[empty_rows, source_column]
    return df


def _merge_alias_columns(df):
    canonical_by_key = {_column_key(column): column for column in PRODUCT_COLUMNS}
    for column in list(df.columns):
        target_column = COLUMN_ALIASES.get(column) or canonical_by_key.get(_column_key(column))
        if target_column and target_column != column:
            df = _merge_column_values(df, column, target_column)

    alias_columns = [
        column
        for column in df.columns
        if (COLUMN_ALIASES.get(column) or canonical_by_key.get(_column_key(column))) != column
        and (COLUMN_ALIASES.get(column) or canonical_by_key.get(_column_key(column))) in PRODUCT_COLUMNS
    ]
    if alias_columns:
        df = df.drop(columns=alias_columns, errors="ignore")
    return df


def ensure_product_dataframe(df):
    if df is None or not isinstance(df, pd.DataFrame):
        df = pd.DataFrame(columns=PRODUCT_COLUMNS)
    else:
        df = df.copy()

    df = _merge_alias_columns(df)

    for column in PRODUCT_COLUMNS:
        if column not in df.columns:
            df[column] = ""
        try:
            df[column] = df[column].astype("object")
        except Exception:
            pass

    empty_stock_count = df["Stok Adedi"].apply(clean_text) == ""
    if empty_stock_count.any():
        df.loc[empty_stock_count, "Stok Adedi"] = df.loc[empty_stock_count, "Stok Miktarı"]

    empty_stock_amount = df["Stok Miktarı"].apply(clean_text) == ""
    if empty_stock_amount.any():
        df.loc[empty_stock_amount, "Stok Miktarı"] = df.loc[empty_stock_amount, "Stok Adedi"]

    empty_status = df["Stok Durumu"].apply(clean_text) == ""
    stock_values = df["Stok Adedi"].apply(lambda value: to_number(value, 0))
    df.loc[empty_status & (stock_values > 0), "Stok Durumu"] = "Var"
    df.loc[empty_status & (stock_values <= 0), "Stok Durumu"] = "Stokta Yok"

    empty_unit = df["Birim"].apply(clean_text) == ""
    df.loc[empty_unit, "Birim"] = "ad"

    def normalize_product_type(value):
        text = normalize_text(value)
        if any(token in text for token in ("hizmet", "stoksuz", "danisman")):
            return "Stoksuz Ürün (Hizmet)"
        return "Stoklu Ürün"

    df["Ürün Tipi"] = df["Ürün Tipi"].apply(normalize_product_type)
    service_rows = df["Ürün Tipi"] == "Stoksuz Ürün (Hizmet)"
    if service_rows.any():
        df.loc[service_rows, "Stok Miktarı"] = 0
        df.loc[service_rows, "Stok Adedi"] = 0
        df.loc[service_rows, "Stok Durumu"] = "Hizmet"
        df.loc[service_rows, "Depo"] = ""

    empty_warehouse = df["Depo"].apply(clean_text) == ""
    df.loc[empty_warehouse & ~service_rows, "Depo"] = DEFAULT_WAREHOUSE

    ordered_columns = PRODUCT_COLUMNS + [column for column in df.columns if column not in PRODUCT_COLUMNS]
    return df[ordered_columns]


def find_product_rows(df, product_name, size="", color="", warehouse="", **kwargs):
    if not size:
        size = kwargs.get("beden", "")
    if not color:
        color = kwargs.get("renk", "")
    if not warehouse:
        warehouse = kwargs.get("depo", "")

    df = ensure_product_dataframe(df)
    if df.empty or "Ürün Adı" not in df.columns:
        return df.iloc[0:0]

    product_key = normalize_text(product_name)
    rows = df[df["Ürün Adı"].apply(normalize_text) == product_key]
    if rows.empty:
        return rows

    filters = [
        ("BEDEN", size),
        ("RENK", color),
        ("Depo", warehouse),
    ]
    for column, value in filters:
        key = normalize_text(value)
        if key and column in rows.columns:
            rows = rows[rows[column].apply(normalize_text) == key]
            if rows.empty:
                return rows
    return rows


def product_price(df, product_name):
    rows = find_product_rows(df, product_name)
    if rows.empty:
        return ""
    return clean_text(rows.iloc[0].get("Satış Fiyatı", "")).replace("TL", "").replace("₺", "").replace("â‚º", "").strip()


def stock_check(df, product_name, quantity, size="", color="", **kwargs):
    if not size:
        size = kwargs.get("beden", "")
    if not color:
        color = kwargs.get("renk", "")
    warehouse = kwargs.get("depo", "")
    product_rows = find_product_rows(df, product_name)
    rows = find_product_rows(df, product_name, size=size, color=color, warehouse=warehouse)
    if rows.empty:
        if not product_rows.empty and any(clean_text(value) for value in (size, color, warehouse)):
            return False, {"reason": "Secilen varyant stok kartinda yok", "stock": None}
        return True, {"reason": "Ürün stok kartında yok", "stock": None}

    row = rows.iloc[0]
    stock = clean_text(row.get("Stok Adedi", row.get("Stok Miktarı", "")))
    if not stock:
        return True, {"reason": "Stok miktarı boş", "stock": None}

    stock_number = to_number(stock, None)
    if stock_number is None:
        return True, {"reason": "Stok miktarı sayısal değil", "stock": stock}

    requested = to_number(quantity, 0)
    return stock_number >= requested, {
        "reason": "",
        "stock": format_number_value(stock_number),
        "requested": format_number_value(requested),
    }


def decrease_stock(df, product_name, quantity, size="", color="", **kwargs):
    if not size:
        size = kwargs.get("beden", "")
    if not color:
        color = kwargs.get("renk", "")
    df = ensure_product_dataframe(df)
    rows = find_product_rows(df, product_name, size=size, color=color, warehouse=kwargs.get("depo", ""))
    if rows.empty:
        return df, {"changed": False, "reason": "Ürün stok kartında yok"}

    index = rows.index[0]
    stock = clean_text(df.loc[index].get("Stok Adedi", df.loc[index].get("Stok Miktarı", "")))
    if not stock:
        return df, {"changed": False, "reason": "Stok miktarı boş"}

    stock_number = to_number(stock, None)
    if stock_number is None:
        return df, {"changed": False, "reason": "Stok miktarı sayısal değil"}

    requested = to_number(quantity, 0)
    new_stock = stock_number - requested
    stock_value = format_number_value(stock_number)
    requested_value = format_number_value(requested)
    new_stock_value = format_number_value(new_stock)
    df.loc[index, "Stok Adedi"] = new_stock_value
    df.loc[index, "Stok Miktarı"] = new_stock_value
    df.loc[index, "Stok Durumu"] = "Stokta Yok" if new_stock_value <= 0 else "Var"
    return df, {"changed": True, "stock": stock_value, "new_stock": new_stock_value, "requested": requested_value}


def critical_stock_rows(df, threshold):
    df = ensure_product_dataframe(df)
    rows = []
    for _, row in df.iterrows():
        stock = clean_text(row.get("Stok Adedi", row.get("Stok Miktarı", "")))
        if not stock:
            continue
        stock_number = to_number(stock, None)
        if stock_number is None:
            continue
        if stock_number < threshold:
            rows.append({
                "Ürün Adı": clean_text(row.get("Ürün Adı", "")),
                "BEDEN": clean_text(row.get("BEDEN", "")),
                "RENK": clean_text(row.get("RENK", "")),
                "Stok": stock_number,
                "Kategori": clean_text(row.get("Kategori", "")),
                "Depo": clean_text(row.get("Depo", "")),
            })
    return rows


def health_issues(df, critical_threshold):
    df = ensure_product_dataframe(df)
    issues = []
    for index, row in df.iterrows():
        product = clean_text(row.get("Ürün Adı", row.get("Ürün", "")))
        stock = to_number(row.get("Stok Adedi", row.get("Stok Miktarı", 0)), 0)
        sale_price = to_number(row.get("Satış Fiyatı", 0), 0)
        label = product or f"Satır {index + 2}"

        if not product:
            issues.append(("Ürün", "Orta", label, "Ürün adı boş.", "Ürün Yönetimi"))
        if stock < 0:
            issues.append(("Stok", "Yüksek", label, f"Stok eksi görünüyor: {stock:g}", "Stok Yönetimi"))
        elif product and stock < critical_threshold:
            issues.append(("Stok", "Orta", label, f"Kritik stok: {stock:g}", "Kritik Stok"))
        if product and sale_price <= 0:
            issues.append(("Ürün", "Düşük", product, "Satış fiyatı boş veya sıfır.", "Ürün Yönetimi"))
    return issues
