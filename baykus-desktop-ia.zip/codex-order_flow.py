import re
from datetime import datetime

import pandas as pd


ORDER_COLUMNS = {
    "Sipariş No": "",
    "Belge Tipi": "Sipariş",
    "Satış Kanalı": "Mağaza",
    "Tarih": "",
    "Müşteri": "",
    "Telefon": "",
    "Tasarım Dosyası": "",
    "Tasarım Onay Durumu": "Bekliyor",
    "Tasarım Onay Tarihi": "",
    "Revizyon Notu": "",
    "Tasarım WhatsApp Tarihi": "",
    "Teslim Tarihi": "",
    "Beden": "",
    "Renk": "",
    "Baskı Türü": "",
    "Kategori": "",
    "Ürün": "",
    "Depo": "",
    "Adet": 0,
    "Birim Fiyat": 0,
    "Toplam": 0,
    "Birim Maliyet": 0,
    "Toplam Maliyet": 0,
    "Kar": 0,
    "Kapora": 0,
    "Kalan Ödeme": 0,
    "İskonto Oranı": 0,
    "İskonto Tutarı": 0,
    "Genel Toplam": 0,
    "Ödeme Türü": "",
    "Banka Hesabı": "",
    "Durum": "Hazırlanıyor",
    "Teklif Durumu": "",
    "Teklif Geçerlilik Tarihi": "",
    "Cari Kart": "",
    "Not": "",
}

ORDER_COLUMN_ALIASES = {
    "SipariÅŸ No": "Sipariş No",
    "SipariÃ…Å¸ No": "Sipariş No",
    "Siparis No": "Sipariş No",
    "SatÄ±ÅŸ KanalÄ±": "Satış Kanalı",
    "SatÃ„Â±Ã…Å¸ KanalÃ„Â±": "Satış Kanalı",
    "Satis Kanali": "Satış Kanalı",
    "MÃ¼ÅŸteri": "Müşteri",
    "MÃƒÂ¼Ã…Å¸teri": "Müşteri",
    "Musteri": "Müşteri",
    "TasarÄ±m DosyasÄ±": "Tasarım Dosyası",
    "TasarÃ„Â±m DosyasÃ„Â±": "Tasarım Dosyası",
    "TasarÄ±m Onay Durumu": "Tasarım Onay Durumu",
    "TasarÃ„Â±m Onay Durumu": "Tasarım Onay Durumu",
    "TasarÄ±m Onay Tarihi": "Tasarım Onay Tarihi",
    "TasarÃ„Â±m Onay Tarihi": "Tasarım Onay Tarihi",
    "TasarÄ±m WhatsApp Tarihi": "Tasarım WhatsApp Tarihi",
    "TasarÃ„Â±m WhatsApp Tarihi": "Tasarım WhatsApp Tarihi",
    "BaskÄ± TÃ¼rÃ¼": "Baskı Türü",
    "BaskÃ„Â± TÃƒÂ¼rÃƒÂ¼": "Baskı Türü",
    "Baski Turu": "Baskı Türü",
    "ÃœrÃ¼n": "Ürün",
    "ÃƒÅ“rÃƒÂ¼n": "Ürün",
    "Urun": "Ürün",
    "Kalan Ã–deme": "Kalan Ödeme",
    "Kalan Ãƒâ€“deme": "Kalan Ödeme",
    "Kalan Odeme": "Kalan Ödeme",
    "Ä°skonto OranÄ±": "İskonto Oranı",
    "Ã„Â°skonto OranÃ„Â±": "İskonto Oranı",
    "Iskonto Orani": "İskonto Oranı",
    "Ä°skonto TutarÄ±": "İskonto Tutarı",
    "Ã„Â°skonto TutarÃ„Â±": "İskonto Tutarı",
    "Iskonto Tutari": "İskonto Tutarı",
    "Ã–deme TÃ¼rÃ¼": "Ödeme Türü",
    "Odeme Turu": "Ödeme Türü",
    "Banka HesabÄ±": "Banka Hesabı",
    "Banka Hesabi": "Banka Hesabı",
    "Teklif GeÃ§erlilik Tarihi": "Teklif Geçerlilik Tarihi",
    "Teklif GeÃƒÂ§erlilik Tarihi": "Teklif Geçerlilik Tarihi",
}


def clean_text(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    text = str(value).strip()
    return "" if text.casefold() in ("nan", "none", "nat", "null") else text


def normalize_text(value):
    return re.sub(r"\s+", " ", clean_text(value)).casefold()


def to_number(value, default=0):
    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    text = str(value).strip().replace("TL", "").replace("₺", "").replace(" ", "")
    if "," in text:
        text = text.replace(".", "").replace(",", ".")
    try:
        return float(text)
    except Exception:
        return default


def format_quantity(value):
    text = clean_text(value)
    if not text:
        return ""
    normalized = text.replace(" ", "")
    if not re.fullmatch(r"[-+]?\d+(?:[.,]\d+)?", normalized):
        return text
    try:
        number = float(normalized.replace(",", "."))
    except Exception:
        return text
    if abs(number - round(number)) < 0.0000001:
        return str(int(round(number)))
    return f"{number:g}".replace(".", ",")


def find_column(df, *names):
    if df is None or not hasattr(df, "columns"):
        return None
    mapping = {normalize_text(column): column for column in df.columns}
    for name in names:
        column = mapping.get(normalize_text(name))
        if column:
            return column
    return None


def _merge_alias_columns(df):
    for old_column, new_column in ORDER_COLUMN_ALIASES.items():
        if old_column not in df.columns:
            continue
        if new_column not in df.columns:
            df[new_column] = df[old_column]
            continue
        empty_rows = df[new_column].apply(clean_text) == ""
        if empty_rows.any():
            df.loc[empty_rows, new_column] = df.loc[empty_rows, old_column]

    alias_columns = [
        old_column
        for old_column, new_column in ORDER_COLUMN_ALIASES.items()
        if old_column != new_column and old_column in df.columns
    ]
    if alias_columns:
        df = df.drop(columns=alias_columns, errors="ignore")
    return df


def ensure_order_dataframe(df):
    if df is None or not isinstance(df, pd.DataFrame):
        df = pd.DataFrame(columns=list(ORDER_COLUMNS.keys()))
    else:
        df = df.copy()

    df = _merge_alias_columns(df)

    for column, default in ORDER_COLUMNS.items():
        if column not in df.columns:
            df[column] = default
        try:
            df[column] = df[column].astype("object")
        except Exception:
            pass

    ordered_columns = list(ORDER_COLUMNS.keys()) + [column for column in df.columns if column not in ORDER_COLUMNS]
    return df[ordered_columns]


def is_quote(value):
    return normalize_text(value) in ("teklif", "proposal", "offer")


def is_order(value):
    return not is_quote(value)


def product_line_text(product, size="", color="", quantity=""):
    product = clean_text(product)
    size = clean_text(size)
    color = clean_text(color)
    quantity = format_quantity(quantity)
    variants = []
    if size:
        variants.append(f"Beden: {size}")
    if color:
        variants.append(f"Renk: {color}")
    variant_text = f" ({', '.join(variants)})" if variants else ""
    quantity_text = f"{quantity} x " if quantity else ""
    return f"{quantity_text}{product}{variant_text}".strip()


def order_product_summary(group, limit=None, max_length=120):
    rows = []
    try:
        iterator = group.iterrows()
    except Exception:
        return ""
    for _, row in iterator:
        text = product_line_text(
            row.get("Ürün", ""),
            row.get("Beden", ""),
            row.get("Renk", ""),
            row.get("Adet", ""),
        )
        if text:
            rows.append(text)
        if limit and len(rows) >= limit:
            break
    summary = " | ".join(rows)
    if max_length and len(summary) > max_length:
        summary = summary[:max_length - 3] + "..."
    return summary


def order_amount_summary(group):
    if group is None or group.empty:
        return {"toplam": 0, "kapora": 0, "kalan": 0, "tahsilat": 0}

    total_column = find_column(group, "Genel Toplam", "GenelToplam")
    line_total_column = find_column(group, "Toplam", "Satır Toplamı", "Satir Toplami")
    if total_column:
        total = sum(to_number(x, 0) for x in group[total_column])
    elif line_total_column:
        total = sum(to_number(x, 0) for x in group[line_total_column])
    else:
        total = 0

    first = group.iloc[0]
    deposit_column = find_column(group, "Kapora", "Tahsilat", "Ödenen", "Odenen")
    deposit = to_number(first.get(deposit_column, 0) if deposit_column else 0, 0)
    fallback_remaining = max(total - deposit, 0)
    remaining_column = find_column(group, "Kalan Ödeme", "Kalan Odeme", "Kalan")
    remaining = to_number(first.get(remaining_column, fallback_remaining) if remaining_column else fallback_remaining, fallback_remaining)
    remaining = max(remaining, 0)
    paid = max(total - remaining, deposit)
    return {
        "toplam": round(total, 2),
        "kapora": round(deposit, 2),
        "kalan": round(remaining, 2),
        "tahsilat": round(paid, 2),
    }


def grouped_orders(df):
    df = ensure_order_dataframe(df)
    order_column = find_column(df, "Sipariş No", "Siparis No", "Belge No")
    if order_column:
        return df.groupby(df[order_column].fillna("").astype(str), dropna=False)
    return [(str(i), df.loc[[i]]) for i in df.index]


def parse_date(value):
    text = clean_text(value)
    if not text:
        return None
    for fmt in ("%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            pass
    try:
        parsed = pd.to_datetime(text, dayfirst=True, errors="coerce")
        if pd.notna(parsed):
            return parsed.to_pydatetime()
    except Exception:
        pass
    return None


def health_issues(df, today=None):
    df = ensure_order_dataframe(df)
    today = today or datetime.now().date()
    issues = []
    seen_numbers = {}

    for index, row in df.iterrows():
        number = clean_text(row.get("Sipariş No", ""))
        customer = clean_text(row.get("Müşteri", ""))
        phone = clean_text(row.get("Telefon", ""))
        document_type = clean_text(row.get("Belge Tipi", ""))
        status = clean_text(row.get("Durum", ""))
        remaining = to_number(row.get("Kalan Ödeme", 0), 0)
        delivery = parse_date(row.get("Teslim Tarihi", ""))
        label = number or customer or f"Satır {index + 2}"

        if not number:
            issues.append(("Sipariş", "Orta", label, "Sipariş no boş.", "Sipariş Listesi"))
        else:
            seen_numbers.setdefault(number, set()).add(normalize_text(document_type))
        if not customer:
            issues.append(("Sipariş", "Düşük", label, "Müşteri bilgisi boş.", "Sipariş Listesi"))
        if customer and not re.sub(r"\D", "", phone):
            issues.append(("Sipariş", "Düşük", label, "Telefon bilgisi boş veya geçersiz.", "Sipariş Listesi"))
        if not is_quote(document_type) and remaining > 0:
            issues.append(("Tahsilat", "Yüksek", label, f"Açık kalan ödeme var: {remaining:g}", "Müşteri Takibi"))
        if not is_quote(document_type) and status != "Teslim Edildi" and delivery and delivery.date() < today:
            issues.append(("Sipariş", "Yüksek", label, f"Teslim tarihi geçmiş: {clean_text(row.get('Teslim Tarihi', ''))}", "Sipariş Listesi"))

    for number, types in seen_numbers.items():
        if len(types) > 1:
            issues.append(("Sipariş", "Orta", number, "Aynı belge numarası farklı belge tipleriyle kullanılıyor.", "Sipariş Listesi"))
    return issues
