import os
import re
import shutil
import sqlite3
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime

import pandas as pd

_EXCEL_CACHE = {}


def _cache_anahtari(dosya_yolu, kwargs):
    abs_yol = os.path.abspath(dosya_yolu)
    try:
        stat = os.stat(abs_yol)
        imza = (stat.st_mtime_ns, stat.st_size)
    except FileNotFoundError:
        imza = (None, None)
    kwargs_key = tuple(sorted((str(k), repr(v)) for k, v in kwargs.items()))
    return abs_yol, imza, kwargs_key


def excel_cache_temizle(dosya_yolu=None):
    if dosya_yolu is None:
        _EXCEL_CACHE.clear()
        return

    abs_yol = os.path.abspath(dosya_yolu)
    for anahtar in list(_EXCEL_CACHE.keys()):
        if anahtar[0] == abs_yol:
            _EXCEL_CACHE.pop(anahtar, None)


def otomatik_yedekleri_temizle(yedek_klasor, dosya_adi, limit=30):
    try:
        if not os.path.exists(yedek_klasor):
            return

        kok_ad, _ = os.path.splitext(dosya_adi)
        yedekler = [
            os.path.join(yedek_klasor, ad)
            for ad in os.listdir(yedek_klasor)
            if ad.startswith(f"{kok_ad}_")
        ]
        yedekler.sort(key=lambda yol: os.path.getmtime(yol), reverse=True)

        for eski_yedek in yedekler[limit:]:
            try:
                os.remove(eski_yedek)
            except Exception:
                pass
    except Exception:
        pass


def guvenli_excel_kaydet(df, dosya_yolu, index=False, yedek_limit=30):
    klasor = os.path.dirname(os.path.abspath(dosya_yolu))
    os.makedirs(klasor, exist_ok=True)

    zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
    gecici_yol = os.path.join(klasor, f".~{os.path.basename(dosya_yolu)}.{zaman}.tmp.xlsx")

    try:
        df.to_excel(gecici_yol, index=index)

        if os.path.exists(dosya_yolu):
            yedek_klasor = os.path.join(klasor, "otomatik_yedekler")
            os.makedirs(yedek_klasor, exist_ok=True)
            dosya_adi, uzanti = os.path.splitext(os.path.basename(dosya_yolu))
            yedek_yol = os.path.join(yedek_klasor, f"{dosya_adi}_{zaman}{uzanti}")
            shutil.copy2(dosya_yolu, yedek_yol)
            otomatik_yedekleri_temizle(yedek_klasor, os.path.basename(dosya_yolu), yedek_limit)

        os.replace(gecici_yol, dosya_yolu)
        excel_cache_temizle(dosya_yolu)
    except Exception:
        try:
            if os.path.exists(gecici_yol):
                os.remove(gecici_yol)
        except Exception:
            pass
        raise


def guvenli_excel_oku(dosya_yolu, data_klasoru=None, **kwargs):
    anahtar = _cache_anahtari(dosya_yolu, kwargs)
    if anahtar in _EXCEL_CACHE:
        return _EXCEL_CACHE[anahtar].copy(deep=True)

    try:
        df = pd.read_excel(dosya_yolu, **kwargs)
        _EXCEL_CACHE[anahtar] = df.copy(deep=True)
        return df
    except Exception as e:
        try:
            if data_klasoru and os.path.exists(dosya_yolu):
                bozuk_klasor = os.path.join(data_klasoru, "bozuk_dosyalar")
                os.makedirs(bozuk_klasor, exist_ok=True)
                zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
                dosya_adi, uzanti = os.path.splitext(os.path.basename(dosya_yolu))
                bozuk_yol = os.path.join(bozuk_klasor, f"{dosya_adi}_okuma_hatasi_{zaman}{uzanti}")
                shutil.copy2(dosya_yolu, bozuk_yol)
        except Exception:
            pass

        raise RuntimeError(f"Excel dosyas? okunamad?: {dosya_yolu}\n{e}") from e


def _sql_adini_koru(ad):
    ad = re.sub(r"[^0-9A-Za-z_]", "_", str(ad).strip())
    ad = re.sub(r"_+", "_", ad).strip("_")
    if not ad:
        ad = "tablo"
    if ad[0].isdigit():
        ad = f"t_{ad}"
    return ad.lower()


def _kolon_adlarini_temizle(kolonlar):
    temizler = []
    sayac = {}

    for i, kolon in enumerate(kolonlar, start=1):
        ad = str(kolon).strip().replace("\n", " ").replace("\r", " ")
        ad = re.sub(r"\s+", " ", ad)
        if not ad or ad.lower() == "nan":
            ad = f"Kolon_{i}"

        adet = sayac.get(ad, 0) + 1
        sayac[ad] = adet
        if adet > 1:
            ad = f"{ad}_{adet}"
        temizler.append(ad)

    return temizler


def _dosya_imzasi(dosya_yolu):
    if not os.path.exists(dosya_yolu):
        return None, None
    stat = os.stat(dosya_yolu)
    return stat.st_size, stat.st_mtime_ns


def _tablo_kolonlari(conn, tablo_adi):
    return [row[1] for row in conn.execute(f'PRAGMA table_info("{tablo_adi}")').fetchall()]


def _eksik_kolon_ekle(conn, tablo_adi, kolon_adi, tip):
    kolonlar = _tablo_kolonlari(conn, tablo_adi)
    if kolon_adi not in kolonlar:
        conn.execute(f'ALTER TABLE "{tablo_adi}" ADD COLUMN "{kolon_adi}" {tip}')


def _ortak_indeksleri_olustur(conn, tablo_adi):
    kolonlar = set(_tablo_kolonlari(conn, tablo_adi))
    adaylar = [
        "\u00dcr\u00fcn Ad\u0131", "Urun Adi", "\u00dcr\u00fcn", "Urun",
        "M\u00fc\u015fteri", "Musteri", "Telefon", "Durum", "Tarih",
        "Kategori", "Tedarik\u00e7i", "Tedarikci", "T\u00fcr", "Tur"
    ]
    for kolon in adaylar:
        if kolon in kolonlar:
            indeks = _sql_adini_koru(f"idx_{tablo_adi}_{kolon}")
            conn.execute(f'CREATE INDEX IF NOT EXISTS "{indeks}" ON "{tablo_adi}" ("{kolon}")')


def sqlite_baglanti(db_dosyasi, data_klasoru):
    os.makedirs(data_klasoru, exist_ok=True)
    os.makedirs(os.path.dirname(os.path.abspath(db_dosyasi)), exist_ok=True)
    conn = sqlite3.connect(db_dosyasi, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA wal_autocheckpoint=1000")
    return conn


def _boyut_yazi(byte_degeri):
    try:
        byte_degeri = float(byte_degeri or 0)
    except Exception:
        byte_degeri = 0
    if byte_degeri >= 1024 * 1024:
        return f"{byte_degeri / (1024 * 1024):.2f} MB"
    if byte_degeri >= 1024:
        return f"{byte_degeri / 1024:.1f} KB"
    return f"{byte_degeri:.0f} B"


def sqlite_yedek_al(db_dosyasi, data_klasoru, neden="bakim", limit=10):
    if not os.path.exists(db_dosyasi):
        return ""

    yedek_klasor = os.path.join(data_klasoru, "sqlite_yedekler")
    os.makedirs(yedek_klasor, exist_ok=True)
    zaman = datetime.now().strftime("%Y%m%d_%H%M%S")
    kok_ad, uzanti = os.path.splitext(os.path.basename(db_dosyasi))
    neden = _sql_adini_koru(neden or "bakim")
    yedek_yolu = os.path.join(yedek_klasor, f"{kok_ad}_{neden}_{zaman}{uzanti or '.db'}")

    with sqlite3.connect(db_dosyasi, timeout=30) as kaynak:
        with sqlite3.connect(yedek_yolu) as hedef:
            kaynak.backup(hedef)

    yedekler = [
        os.path.join(yedek_klasor, ad)
        for ad in os.listdir(yedek_klasor)
        if ad.startswith(f"{kok_ad}_") and ad.endswith(uzanti or ".db")
    ]
    yedekler.sort(key=lambda yol: os.path.getmtime(yol), reverse=True)
    for eski_yedek in yedekler[int(limit):]:
        try:
            os.remove(eski_yedek)
        except Exception:
            pass
    return yedek_yolu


def sqlite_hazirla(db_dosyasi, data_klasoru):
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sistem_bilgisi (
                anahtar TEXT PRIMARY KEY,
                deger TEXT,
                guncelleme_tarihi TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS aktarim_bilgisi (
                tablo TEXT PRIMARY KEY,
                kaynak_dosya TEXT,
                satir_sayisi INTEGER,
                aktarim_tarihi TEXT
            )
            """
        )
        for kolon, tip in [
            ("baslik", "TEXT"),
            ("kaynak_boyut", "INTEGER"),
            ("kaynak_degisim", "INTEGER"),
            ("kolon_sayisi", "INTEGER"),
            ("durum", "TEXT"),
            ("hata", "TEXT"),
        ]:
            _eksik_kolon_ekle(conn, "aktarim_bilgisi", kolon, tip)

        conn.execute(
            """
            INSERT OR REPLACE INTO sistem_bilgisi (anahtar, deger, guncelleme_tarihi)
            VALUES (?, ?, ?)
            """,
            ("sema_surumu", "1", datetime.now().strftime("%d.%m.%Y %H:%M:%S"))
        )
        conn.commit()


def excel_verilerini_sqlite_aktar(veri_dosyalari, db_dosyasi, data_klasoru):
    if os.path.exists(db_dosyasi):
        try:
            sqlite_yedek_al(db_dosyasi, data_klasoru, neden="aktarim_oncesi")
        except Exception:
            pass
    sqlite_hazirla(db_dosyasi, data_klasoru)
    sonuc = []

    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        for tablo_adi, bilgi in veri_dosyalari.items():
            dosya_yolu = bilgi["dosya"] if isinstance(bilgi, dict) else bilgi
            baslik = bilgi.get("baslik", tablo_adi) if isinstance(bilgi, dict) else tablo_adi
            tablo_adi = _sql_adini_koru(tablo_adi)
            kaynak_boyut, kaynak_degisim = _dosya_imzasi(dosya_yolu)

            if not os.path.exists(dosya_yolu):
                conn.execute(
                    """
                    INSERT OR REPLACE INTO aktarim_bilgisi
                    (tablo, baslik, kaynak_dosya, satir_sayisi, aktarim_tarihi, kaynak_boyut, kaynak_degisim, kolon_sayisi, durum, hata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (tablo_adi, baslik, dosya_yolu, 0, datetime.now().strftime("%d.%m.%Y %H:%M:%S"), kaynak_boyut, kaynak_degisim, 0, "Dosya yok", "")
                )
                sonuc.append((tablo_adi, "Atlandi", "Dosya yok"))
                continue

            try:
                df = guvenli_excel_oku(dosya_yolu, data_klasoru).copy()
                df.columns = _kolon_adlarini_temizle(df.columns)
                if "_excel_satir_no" in df.columns:
                    df = df.rename(columns={"_excel_satir_no": "excel_satir_no"})
                df.insert(0, "_excel_satir_no", range(2, len(df) + 2))
                df = df.where(pd.notna(df), None)

                df.to_sql(tablo_adi, conn, if_exists="replace", index=False)
                _ortak_indeksleri_olustur(conn, tablo_adi)
                conn.execute(
                    """
                    INSERT OR REPLACE INTO aktarim_bilgisi
                    (tablo, baslik, kaynak_dosya, satir_sayisi, aktarim_tarihi, kaynak_boyut, kaynak_degisim, kolon_sayisi, durum, hata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        tablo_adi,
                        baslik,
                        dosya_yolu,
                        len(df),
                        datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
                        kaynak_boyut,
                        kaynak_degisim,
                        len(df.columns),
                        "Aktarildi",
                        "",
                    )
                )
                sonuc.append((tablo_adi, "Aktarildi", f"{len(df)} satir"))
            except Exception as e:
                conn.execute(
                    """
                    INSERT OR REPLACE INTO aktarim_bilgisi
                    (tablo, baslik, kaynak_dosya, satir_sayisi, aktarim_tarihi, kaynak_boyut, kaynak_degisim, kolon_sayisi, durum, hata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (tablo_adi, baslik, dosya_yolu, 0, datetime.now().strftime("%d.%m.%Y %H:%M:%S"), kaynak_boyut, kaynak_degisim, 0, "Hata", str(e))
                )
                sonuc.append((tablo_adi, "Hata", str(e)))

        conn.execute("PRAGMA optimize")
        conn.commit()

    return sonuc


def sqlite_bakim_yap(db_dosyasi, data_klasoru):
    sonuclar = []

    def ekle(kategori, durum, detay, onem="Düşük"):
        sonuclar.append({
            "kategori": kategori,
            "durum": durum,
            "detay": detay,
            "onem": onem,
        })

    if not os.path.exists(db_dosyasi):
        ekle("Veritabanı", "Hata", "SQLite dosyası bulunamadı.", "Yüksek")
        return sonuclar

    try:
        yedek_yolu = sqlite_yedek_al(db_dosyasi, data_klasoru, neden="bakim")
        if yedek_yolu:
            ekle("Yedek", "Tamam", f"Bakım öncesi yedek alındı: {os.path.basename(yedek_yolu)}")
    except Exception as e:
        ekle("Yedek", "Uyarı", f"Bakım öncesi yedek alınamadı: {e}", "Orta")

    try:
        with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
            conn.execute("PRAGMA optimize")
            checkpoint = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            conn.commit()
        detay = "WAL temizlendi."
        if checkpoint:
            detay += f" Sonuç: {tuple(checkpoint)}"
        ekle("Bakım", "Tamam", detay)
    except Exception as e:
        ekle("Bakım", "Hata", str(e), "Yüksek")

    return sonuclar


def sqlite_saglik_kontrol(db_dosyasi, data_klasoru, veri_dosyalari=None):
    sonuclar = []

    def ekle(kategori, durum, detay, onem="Düşük"):
        sonuclar.append({
            "kategori": kategori,
            "durum": durum,
            "detay": detay,
            "onem": onem,
        })

    if not os.path.exists(db_dosyasi):
        ekle("Veritabanı", "Hata", "SQLite dosyası bulunamadı.", "Yüksek")
        return sonuclar

    try:
        boyut = os.path.getsize(db_dosyasi)
        guncelleme = datetime.fromtimestamp(os.path.getmtime(db_dosyasi)).strftime("%d.%m.%Y %H:%M")
        ekle("Dosya", "Bilgi", f"Boyut: {_boyut_yazi(boyut)} | Son değişiklik: {guncelleme}")
    except Exception as e:
        ekle("Dosya", "Uyarı", f"Dosya bilgisi okunamadı: {e}", "Orta")

    try:
        sqlite_hazirla(db_dosyasi, data_klasoru)
        with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            ekle("Bütünlük", "Tamam" if integrity == "ok" else "Hata", str(integrity), "Düşük" if integrity == "ok" else "Yüksek")

            quick = conn.execute("PRAGMA quick_check").fetchone()[0]
            ekle("Hızlı Kontrol", "Tamam" if quick == "ok" else "Hata", str(quick), "Düşük" if quick == "ok" else "Yüksek")

            journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            durum = "Tamam" if str(journal_mode).casefold() == "wal" else "Uyarı"
            ekle("Çalışma Modu", durum, f"Journal: {journal_mode}", "Düşük" if durum == "Tamam" else "Orta")

            checkpoint = conn.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
            if checkpoint:
                ekle("WAL", "Bilgi", f"Kontrol sonucu: {tuple(checkpoint)}")

            tablolar = [
                row[0]
                for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
                ).fetchall()
            ]
            ekle("Tablolar", "Tamam" if tablolar else "Uyarı", f"{len(tablolar)} tablo bulundu.", "Düşük" if tablolar else "Orta")

            if veri_dosyalari:
                beklenenler = {_sql_adini_koru(ad) for ad in veri_dosyalari.keys()}
                eksikler = sorted(beklenenler - set(tablolar))
                if eksikler:
                    ekle("Eksik Tablo", "Uyarı", ", ".join(eksikler[:12]), "Orta")

            aktarimlar = conn.execute(
                """
                SELECT tablo, baslik, kaynak_dosya, kaynak_boyut, kaynak_degisim, durum, hata
                FROM aktarim_bilgisi
                ORDER BY tablo
                """
            ).fetchall()
            hatali = [row for row in aktarimlar if row["durum"] not in ("Aktarildi", "SQLite")]
            if hatali:
                for row in hatali[:12]:
                    detay = row["hata"] or row["durum"] or "Aktarım sorunu"
                    ekle("Aktarım", "Uyarı", f"{row['baslik'] or row['tablo']}: {detay}", "Orta")
            else:
                ekle("Aktarım", "Tamam", f"{len(aktarimlar)} kayıt güncel görünüyor.")

            for row in aktarimlar:
                kaynak = row["kaynak_dosya"]
                if not kaynak or not os.path.exists(kaynak):
                    continue
                kaynak_boyut, kaynak_degisim = _dosya_imzasi(kaynak)
                if row["durum"] == "Aktarildi" and (row["kaynak_boyut"] != kaynak_boyut or row["kaynak_degisim"] != kaynak_degisim):
                    ekle("Kaynak Uyumu", "Uyarı", f"{row['baslik'] or row['tablo']} Excel dosyası değişmiş; SQLite güncelleme bekliyor.", "Orta")
    except Exception as e:
        ekle("SQLite", "Hata", str(e), "Yüksek")

    return sonuclar


def sqlite_tablo_bilgileri(db_dosyasi, data_klasoru):
    if not os.path.exists(db_dosyasi):
        return []

    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        tablo_adlari = pd.read_sql_query(
            """
            SELECT name
            FROM sqlite_master
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
            """,
            conn
        )["name"].tolist()

        bilgiler = []
        for tablo_adi in tablo_adlari:
            satir_sayisi = conn.execute(f'SELECT COUNT(*) FROM "{tablo_adi}"').fetchone()[0]
            bilgiler.append((tablo_adi, satir_sayisi))

    return bilgiler


def sqlite_tablo_onizleme(tablo_adi, db_dosyasi, data_klasoru, limit=100):
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        return pd.read_sql_query(f'SELECT * FROM "{tablo_adi}" LIMIT {int(limit)}', conn)


def sqlite_df_oku(tablo_adi, db_dosyasi, data_klasoru, limit=None):
    tablo_adi = _sql_adini_koru(tablo_adi)
    sorgu = f'SELECT * FROM "{tablo_adi}"'
    if limit is not None:
        sorgu += f" LIMIT {int(limit)}"
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        return pd.read_sql_query(sorgu, conn)


def sqlite_tablo_var_mi(tablo_adi, db_dosyasi, data_klasoru):
    tablo_adi = _sql_adini_koru(tablo_adi)
    if not os.path.exists(db_dosyasi):
        return False
    sqlite_hazirla(db_dosyasi, data_klasoru)
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (tablo_adi,)
        ).fetchone()
        return row is not None


def sqlite_df_kaydet(tablo_adi, df, db_dosyasi, data_klasoru, baslik=None, kaynak_dosya="SQLite"):
    sqlite_hazirla(db_dosyasi, data_klasoru)
    tablo_adi = _sql_adini_koru(tablo_adi)
    kayit = df.copy()
    kayit.columns = _kolon_adlarini_temizle(kayit.columns)
    if len(kayit.columns) == 0:
        kayit = pd.DataFrame(columns=["_kayit_id"])
    if "_excel_satir_no" in kayit.columns:
        kayit = kayit.drop(columns=["_excel_satir_no"])
    kayit = kayit.where(pd.notna(kayit), None)

    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        kayit.to_sql(tablo_adi, conn, if_exists="replace", index=False)
        _ortak_indeksleri_olustur(conn, tablo_adi)
        conn.execute(
            """
            INSERT OR REPLACE INTO aktarim_bilgisi
            (tablo, baslik, kaynak_dosya, satir_sayisi, aktarim_tarihi, kaynak_boyut, kaynak_degisim, kolon_sayisi, durum, hata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                tablo_adi,
                baslik or tablo_adi,
                kaynak_dosya,
                len(kayit),
                datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
                0,
                0,
                len(kayit.columns),
                "SQLite",
                "",
            )
        )
        conn.execute("PRAGMA optimize")
        conn.commit()

    excel_cache_temizle()
    return True


def sqlite_df_oku_temiz(tablo_adi, db_dosyasi, data_klasoru, limit=None):
    df = sqlite_df_oku(tablo_adi, db_dosyasi, data_klasoru, limit=limit)
    if "_excel_satir_no" in df.columns:
        df = df.drop(columns=["_excel_satir_no"])
    return df


def sqlite_aktarim_bilgileri(db_dosyasi, data_klasoru):
    if not os.path.exists(db_dosyasi):
        return []

    sqlite_hazirla(db_dosyasi, data_klasoru)
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        rows = conn.execute(
            """
            SELECT tablo, baslik, satir_sayisi, kolon_sayisi, durum,
                   aktarim_tarihi, kaynak_boyut, kaynak_degisim, kaynak_dosya, hata
            FROM aktarim_bilgisi
            ORDER BY tablo
            """
        ).fetchall()
        return [dict(row) for row in rows]


def sqlite_excel_guncel_mi(tablo_adi, dosya_yolu, db_dosyasi, data_klasoru):
    if not os.path.exists(db_dosyasi) or not os.path.exists(dosya_yolu):
        return False

    tablo_adi = _sql_adini_koru(tablo_adi)
    kaynak_boyut, kaynak_degisim = _dosya_imzasi(dosya_yolu)
    sqlite_hazirla(db_dosyasi, data_klasoru)
    with sqlite_baglanti(db_dosyasi, data_klasoru) as conn:
        row = conn.execute(
            """
            SELECT kaynak_boyut, kaynak_degisim, durum
            FROM aktarim_bilgisi
            WHERE tablo = ?
            """,
            (tablo_adi,)
        ).fetchone()
        if row is None:
            return False
        return (
            row["durum"] == "Aktarildi" and
            row["kaynak_boyut"] == kaynak_boyut and
            row["kaynak_degisim"] == kaynak_degisim
        )


def veri_dosyasi_durumlari(veri_dosyalari, db_dosyasi, data_klasoru):
    durumlar = []

    for tablo_adi, bilgi in veri_dosyalari.items():
        dosya_yolu = bilgi["dosya"]
        baslik = bilgi.get("baslik", tablo_adi)

        if not os.path.exists(dosya_yolu):
            durumlar.append({
                "tablo": tablo_adi,
                "baslik": baslik,
                "dosya": dosya_yolu,
                "durum": "Dosya yok",
                "satir": "-",
                "boyut": "-",
                "degisim": "-",
            })
            continue

        try:
            df = guvenli_excel_oku(dosya_yolu, data_klasoru)
            durum = "Tamam"
            satir = len(df)
        except Exception:
            durum = "Okuma hatası"
            satir = "-"

        boyut_kb = os.path.getsize(dosya_yolu) / 1024
        degisim = datetime.fromtimestamp(os.path.getmtime(dosya_yolu)).strftime("%d.%m.%Y %H:%M")
        durumlar.append({
            "tablo": tablo_adi,
            "baslik": baslik,
            "dosya": dosya_yolu,
            "durum": durum,
            "satir": satir,
            "boyut": f"{boyut_kb:.1f} KB",
            "degisim": degisim,
        })

    return durumlar


def postgres_surucu_bilgisi():
    try:
        import psycopg  # type: ignore
        return "psycopg", psycopg
    except Exception:
        pass
    try:
        import psycopg2  # type: ignore
        return "psycopg2", psycopg2
    except Exception:
        pass
    return None, None


def postgres_baglanti(config):
    surucu_adi, surucu = postgres_surucu_bilgisi()
    if surucu is None:
        raise RuntimeError("PostgreSQL bağlantı kütüphanesi bulunamadı. Kurulum: pip install psycopg[binary]")

    host = str(config.get("host", "")).strip()
    port = int(str(config.get("port", "5432")).strip() or "5432")
    dbname = str(config.get("dbname", "")).strip()
    user = str(config.get("user", "")).strip()
    password = str(config.get("password", ""))
    sslmode = str(config.get("sslmode", "disable")).strip() or "disable"

    if not host or not dbname or not user:
        raise RuntimeError("PostgreSQL için sunucu, veritabanı ve kullanıcı alanları gereklidir.")

    return surucu.connect(
        host=host,
        port=port,
        dbname=dbname,
        user=user,
        password=password,
        sslmode=sslmode,
    )


def postgres_baglanti_test(config):
    surucu_adi, _ = postgres_surucu_bilgisi()
    with postgres_baglanti(config) as conn:
        cur = conn.cursor()
        cur.execute("SELECT version()")
        version = cur.fetchone()[0]
        cur.close()
    return surucu_adi, version


def _postgres_tip_bul(series):
    if pd.api.types.is_integer_dtype(series):
        return "BIGINT"
    if pd.api.types.is_float_dtype(series):
        return "DOUBLE PRECISION"
    if pd.api.types.is_bool_dtype(series):
        return "BOOLEAN"
    return "TEXT"


def _postgres_deger_temizle(deger):
    if pd.isna(deger):
        return None
    if isinstance(deger, pd.Timestamp):
        return deger.isoformat()
    return deger


def sqlite_verilerini_postgres_aktar(sqlite_db_dosyasi, data_klasoru, pg_config, tablo_adlari=None, replace=True):
    if not os.path.exists(sqlite_db_dosyasi):
        raise RuntimeError(f"SQLite veritabanı bulunamadı: {sqlite_db_dosyasi}")

    sqlite_hazirla(sqlite_db_dosyasi, data_klasoru)
    sonuc = []

    with sqlite_baglanti(sqlite_db_dosyasi, data_klasoru) as sqlite_conn:
        if tablo_adlari is None:
            tablo_adlari = pd.read_sql_query(
                """
                SELECT name
                FROM sqlite_master
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                ORDER BY name
                """,
                sqlite_conn
            )["name"].tolist()

        with postgres_baglanti(pg_config) as pg_conn:
            cur = pg_conn.cursor()
            for tablo_adi in tablo_adlari:
                df = pd.read_sql_query(f'SELECT * FROM "{tablo_adi}"', sqlite_conn)
                temiz_tablo = _sql_adini_koru(tablo_adi)
                kolonlar = _kolon_adlarini_temizle(df.columns)
                df.columns = kolonlar

                try:
                    if replace:
                        cur.execute(f'DROP TABLE IF EXISTS "{temiz_tablo}"')

                    kolon_sql = []
                    for kolon in kolonlar:
                        kolon_sql.append(f'"{kolon}" {_postgres_tip_bul(df[kolon])}')
                    cur.execute(f'CREATE TABLE IF NOT EXISTS "{temiz_tablo}" ({", ".join(kolon_sql)})')

                    if replace and not df.empty:
                        yer_tutucu = ", ".join(["%s"] * len(kolonlar))
                        kolon_adlari = ", ".join([f'"{k}"' for k in kolonlar])
                        sql = f'INSERT INTO "{temiz_tablo}" ({kolon_adlari}) VALUES ({yer_tutucu})'
                        satirlar = [
                            tuple(_postgres_deger_temizle(row[k]) for k in kolonlar)
                            for _, row in df.iterrows()
                        ]
                        cur.executemany(sql, satirlar)

                    sonuc.append((temiz_tablo, "Aktarıldı", f"{len(df)} satır"))
                except Exception as e:
                    sonuc.append((temiz_tablo, "Hata", str(e)))

            pg_conn.commit()
            cur.close()

    return sonuc


def mysql_surucu_bilgisi():
    try:
        import mysql.connector  # type: ignore
        return "mysql-connector-python", mysql.connector
    except Exception:
        pass
    try:
        import pymysql  # type: ignore
        return "pymysql", pymysql
    except Exception:
        pass
    return None, None


def mysql_baglanti(config):
    surucu_adi, surucu = mysql_surucu_bilgisi()
    if surucu is None:
        raise RuntimeError("MySQL baglanti kutuphanesi bulunamadi. Kurulum: pip install mysql-connector-python")

    host = str(config.get("host", "")).strip()
    port = int(str(config.get("port", "3306")).strip() or "3306")
    dbname = str(config.get("dbname", "")).strip()
    user = str(config.get("user", "")).strip()
    password = str(config.get("password", ""))

    if not host or not dbname or not user:
        raise RuntimeError("MySQL icin sunucu, veritabani ve kullanici alanlari gereklidir.")

    if surucu_adi == "pymysql":
        return surucu.connect(
            host=host,
            port=port,
            database=dbname,
            user=user,
            password=password,
            charset="utf8mb4",
            autocommit=False,
        )

    return surucu.connect(
        host=host,
        port=port,
        database=dbname,
        user=user,
        password=password,
        charset="utf8mb4",
        use_unicode=True,
    )


def merkezi_db_turu(config):
    tur = str(config.get("engine", config.get("db_type", "PostgreSQL")) or "PostgreSQL").strip()
    if tur.lower() in ("mysql", "mariadb"):
        return "MySQL"
    return "PostgreSQL"


def merkezi_db_surucu_bilgisi(config):
    if merkezi_db_turu(config) == "MySQL":
        return mysql_surucu_bilgisi()
    return postgres_surucu_bilgisi()


def merkezi_db_baglanti(config):
    if merkezi_db_turu(config) == "MySQL":
        return mysql_baglanti(config)
    return postgres_baglanti(config)


def merkezi_db_baglanti_test(config):
    surucu_adi, _ = merkezi_db_surucu_bilgisi(config)
    conn = merkezi_db_baglanti(config)
    try:
        cur = conn.cursor()
        cur.execute("SELECT VERSION()")
        version = cur.fetchone()[0]
        cur.close()
        return merkezi_db_turu(config), surucu_adi, version
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _merkezi_sql_ad(engine, ad):
    temiz = _sql_adini_koru(ad)
    if engine == "MySQL":
        return f"`{temiz}`"
    return f'"{temiz}"'


def _merkezi_kolon_haritasi(kolonlar):
    sonuc = []
    kullanilan = set()
    for kolon in kolonlar:
        temiz = _sql_adini_koru(kolon)
        taban = temiz
        sayac = 2
        while temiz in kullanilan:
            temiz = f"{taban}_{sayac}"
            sayac += 1
        kullanilan.add(temiz)
        sonuc.append((kolon, temiz))
    return sonuc


def _merkezi_tip_bul(series, engine):
    if pd.api.types.is_integer_dtype(series):
        return "BIGINT"
    if pd.api.types.is_float_dtype(series):
        return "DOUBLE" if engine == "MySQL" else "DOUBLE PRECISION"
    if pd.api.types.is_bool_dtype(series):
        return "TINYINT(1)" if engine == "MySQL" else "BOOLEAN"
    return "TEXT"


def sqlite_verilerini_merkezi_db_aktar(sqlite_db_dosyasi, data_klasoru, db_config, tablo_adlari=None, replace=True):
    if not os.path.exists(sqlite_db_dosyasi):
        raise RuntimeError(f"SQLite veritabani bulunamadi: {sqlite_db_dosyasi}")

    sqlite_hazirla(sqlite_db_dosyasi, data_klasoru)
    engine = merkezi_db_turu(db_config)
    sonuc = []

    with sqlite_baglanti(sqlite_db_dosyasi, data_klasoru) as sqlite_conn:
        if tablo_adlari is None:
            tablo_adlari = pd.read_sql_query(
                """
                SELECT name
                FROM sqlite_master
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                ORDER BY name
                """,
                sqlite_conn
            )["name"].tolist()

        conn = merkezi_db_baglanti(db_config)
        try:
            cur = conn.cursor()
            for tablo_adi in tablo_adlari:
                df = pd.read_sql_query(f'SELECT * FROM "{tablo_adi}"', sqlite_conn)
                temiz_tablo = _sql_adini_koru(tablo_adi)
                kolonlar = _kolon_adlarini_temizle(df.columns)
                df.columns = kolonlar

                try:
                    tablo_sql = _merkezi_sql_ad(engine, temiz_tablo)
                    if replace:
                        cur.execute(f"DROP TABLE IF EXISTS {tablo_sql}")

                    if not kolonlar:
                        kolonlar = ["kayit_id"]
                        df = pd.DataFrame(columns=kolonlar)

                    kolon_haritasi = _merkezi_kolon_haritasi(kolonlar)
                    kolon_sql = []
                    for kaynak_kolon, sql_kolon in kolon_haritasi:
                        kolon_sql.append(f"{_merkezi_sql_ad(engine, sql_kolon)} {_merkezi_tip_bul(df[kaynak_kolon], engine)}")
                    cur.execute(f"CREATE TABLE IF NOT EXISTS {tablo_sql} ({', '.join(kolon_sql)})")

                    if replace and not df.empty:
                        yer_tutucu = ", ".join(["%s"] * len(kolon_haritasi))
                        kolon_adlari = ", ".join([_merkezi_sql_ad(engine, sql_kolon) for _, sql_kolon in kolon_haritasi])
                        sql = f"INSERT INTO {tablo_sql} ({kolon_adlari}) VALUES ({yer_tutucu})"
                        satirlar = [
                            tuple(_postgres_deger_temizle(row[kaynak_kolon]) for kaynak_kolon, _ in kolon_haritasi)
                            for _, row in df.iterrows()
                        ]
                        cur.executemany(sql, satirlar)

                    sonuc.append((temiz_tablo, "Aktarildi", f"{len(df)} satir"))
                except Exception as e:
                    sonuc.append((temiz_tablo, "Hata", str(e)))

            conn.commit()
            cur.close()
        finally:
            try:
                conn.close()
            except Exception:
                pass

    return sonuc


def merkezi_yetki_semasi_hazirla(db_config):
    engine = merkezi_db_turu(db_config)
    bool_tip = "TINYINT(1)" if engine == "MySQL" else "BOOLEAN"
    aktif_default = "1" if engine == "MySQL" else "TRUE"
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)

    komutlar = [
        f"""
        CREATE TABLE IF NOT EXISTS {tablo("app_roles")} (
            role_code VARCHAR(30) PRIMARY KEY,
            role_name VARCHAR(80) NOT NULL,
            description TEXT
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {tablo("app_users")} (
            id VARCHAR(36) PRIMARY KEY,
            username VARCHAR(80) NOT NULL UNIQUE,
            password_hash VARCHAR(256) NOT NULL,
            full_name VARCHAR(160),
            role_code VARCHAR(30) NOT NULL,
            computer_name VARCHAR(120),
            device_id VARCHAR(120),
            is_active {bool_tip} NOT NULL DEFAULT {aktif_default},
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login_at TIMESTAMP NULL
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {tablo("app_devices")} (
            device_id VARCHAR(120) PRIMARY KEY,
            computer_name VARCHAR(120),
            assigned_username VARCHAR(80),
            is_active {bool_tip} NOT NULL DEFAULT {aktif_default},
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_seen_at TIMESTAMP NULL
        )
        """,
        f"""
        CREATE TABLE IF NOT EXISTS {tablo("app_audit_log")} (
            id VARCHAR(36) PRIMARY KEY,
            username VARCHAR(80),
            role_code VARCHAR(30),
            device_id VARCHAR(120),
            action VARCHAR(120) NOT NULL,
            detail TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
    ]

    roller = [
        ("yonetici", "Yonetici", "Tum ayarlar, kullanici yonetimi, raporlar ve veri aktarim yetkisi."),
        ("personel", "Personel", "Gunluk satis, siparis, musteri ve stok ekranlari icin sinirli yetki."),
    ]

    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        for komut in komutlar:
            cur.execute(komut)

        if engine == "MySQL":
            rol_sql = (
                f"INSERT INTO {tablo('app_roles')} (role_code, role_name, description) "
                "VALUES (%s, %s, %s) "
                "ON DUPLICATE KEY UPDATE role_name=VALUES(role_name), description=VALUES(description)"
            )
        else:
            rol_sql = (
                f"INSERT INTO {tablo('app_roles')} (role_code, role_name, description) "
                "VALUES (%s, %s, %s) "
                "ON CONFLICT (role_code) DO UPDATE SET "
                "role_name=EXCLUDED.role_name, description=EXCLUDED.description"
            )
        cur.executemany(rol_sql, roller)
        conn.commit()
        cur.close()
    finally:
        try:
            conn.close()
        except Exception:
            pass

    return [
        ("app_roles", "Hazir", "Personel/Yonetici rolleri"),
        ("app_users", "Hazir", "Bilgisayar bazli kullanici girisi"),
        ("app_devices", "Hazir", "Her bilgisayar icin cihaz kaydi"),
        ("app_audit_log", "Hazir", "Islem kaydi temeli"),
    ]


def sifre_hash_uret(sifre, iterasyon=260000):
    sifre = str(sifre or "")
    salt = secrets.token_hex(16)
    ozet = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), salt.encode("ascii"), iterasyon)
    return f"pbkdf2_sha256${iterasyon}${salt}${ozet.hex()}"


def sifre_hash_dogrula(sifre, kayitli_hash):
    try:
        algoritma, iterasyon, salt, beklenen = str(kayitli_hash or "").split("$", 3)
        if algoritma != "pbkdf2_sha256":
            return False
        ozet = hashlib.pbkdf2_hmac(
            "sha256",
            str(sifre or "").encode("utf-8"),
            salt.encode("ascii"),
            int(iterasyon),
        ).hex()
        return hmac.compare_digest(ozet, beklenen)
    except Exception:
        return False


def merkezi_kullanici_olustur(db_config, username, password, full_name="", role_code="personel", computer_name="", device_id=""):
    username = str(username or "").strip()
    role_code = str(role_code or "personel").strip().lower()
    if role_code not in ("personel", "yonetici"):
        raise RuntimeError("Rol personel veya yonetici olmalidir.")
    if not username:
        raise RuntimeError("Kullanici adi gereklidir.")
    if not str(password or ""):
        raise RuntimeError("Sifre gereklidir.")

    merkezi_yetki_semasi_hazirla(db_config)
    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    kullanici_id = str(uuid.uuid4())
    password_hash = sifre_hash_uret(password)

    if engine == "MySQL":
        sql = (
            f"INSERT INTO {tablo('app_users')} "
            "(id, username, password_hash, full_name, role_code, computer_name, device_id, is_active) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, 1) "
            "ON DUPLICATE KEY UPDATE "
            "password_hash=VALUES(password_hash), full_name=VALUES(full_name), role_code=VALUES(role_code), "
            "computer_name=VALUES(computer_name), device_id=VALUES(device_id), is_active=1"
        )
    else:
        sql = (
            f"INSERT INTO {tablo('app_users')} "
            "(id, username, password_hash, full_name, role_code, computer_name, device_id, is_active) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, TRUE) "
            "ON CONFLICT (username) DO UPDATE SET "
            "password_hash=EXCLUDED.password_hash, full_name=EXCLUDED.full_name, role_code=EXCLUDED.role_code, "
            "computer_name=EXCLUDED.computer_name, device_id=EXCLUDED.device_id, is_active=TRUE"
        )

    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(sql, (kullanici_id, username, password_hash, full_name, role_code, computer_name, device_id))
        conn.commit()
        cur.close()
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return kullanici_id


def merkezi_kullanici_dogrula(db_config, username, password, device_id=""):
    username = str(username or "").strip()
    if not username:
        return None

    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    aktif_kosul = "is_active = 1" if engine == "MySQL" else "is_active = TRUE"
    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(
            f"SELECT id, username, password_hash, full_name, role_code FROM {tablo('app_users')} "
            f"WHERE username = %s AND {aktif_kosul}",
            (username,)
        )
        row = cur.fetchone()
        if not row or not sifre_hash_dogrula(password, row[2]):
            cur.close()
            return None

        cur.execute(
            f"UPDATE {tablo('app_users')} SET last_login_at = CURRENT_TIMESTAMP, device_id = %s WHERE username = %s",
            (device_id, username)
        )
        conn.commit()
        cur.close()
        return {
            "id": row[0],
            "username": row[1],
            "full_name": row[3],
            "role_code": row[4],
        }
    finally:
        try:
            conn.close()
        except Exception:
            pass


def merkezi_kullanicilari_listele(db_config):
    merkezi_yetki_semasi_hazirla(db_config)
    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(
            f"""
            SELECT username, full_name, role_code, computer_name, device_id, is_active,
                   created_at, last_login_at
            FROM {tablo('app_users')}
            ORDER BY username
            """
        )
        rows = cur.fetchall()
        cur.close()
        sonuc = []
        for row in rows:
            sonuc.append({
                "username": row[0],
                "full_name": row[1],
                "role_code": row[2],
                "computer_name": row[3],
                "device_id": row[4],
                "is_active": bool(row[5]),
                "created_at": row[6],
                "last_login_at": row[7],
            })
        return sonuc
    finally:
        try:
            conn.close()
        except Exception:
            pass


def merkezi_kullanici_aktiflik_ayarla(db_config, username, aktif=True):
    username = str(username or "").strip()
    if not username:
        raise RuntimeError("Kullanici adi gereklidir.")
    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    aktif_deger = bool(aktif)
    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(
            f"UPDATE {tablo('app_users')} SET is_active = %s WHERE username = %s",
            (aktif_deger, username)
        )
        conn.commit()
        cur.close()
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return True


def merkezi_kullanici_bilgi_guncelle(db_config, username, full_name="", role_code="personel", computer_name="", device_id="", password=None):
    username = str(username or "").strip()
    role_code = str(role_code or "personel").strip().lower()
    if role_code not in ("personel", "yonetici"):
        raise RuntimeError("Rol personel veya yonetici olmalidir.")
    if not username:
        raise RuntimeError("Kullanici adi gereklidir.")

    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    alanlar = [
        "full_name = %s",
        "role_code = %s",
        "computer_name = %s",
        "device_id = %s",
    ]
    degerler = [full_name, role_code, computer_name, device_id]
    if password:
        alanlar.append("password_hash = %s")
        degerler.append(sifre_hash_uret(password))
    degerler.append(username)

    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(
            f"UPDATE {tablo('app_users')} SET {', '.join(alanlar)} WHERE username = %s",
            tuple(degerler)
        )
        conn.commit()
        cur.close()
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return True


def merkezi_kullanici_sil(db_config, username):
    username = str(username or "").strip()
    if not username:
        raise RuntimeError("Kullanici adi gereklidir.")
    engine = merkezi_db_turu(db_config)
    tablo = lambda ad: _merkezi_sql_ad(engine, ad)
    conn = merkezi_db_baglanti(db_config)
    try:
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {tablo('app_users')} WHERE username = %s", (username,))
        conn.commit()
        cur.close()
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return True


def merkezi_audit_log_ekle(db_config, username, role_code, device_id, action, detail=""):
    try:
        merkezi_yetki_semasi_hazirla(db_config)
        engine = merkezi_db_turu(db_config)
        tablo = lambda ad: _merkezi_sql_ad(engine, ad)
        conn = merkezi_db_baglanti(db_config)
        try:
            cur = conn.cursor()
            cur.execute(
                f"""
                INSERT INTO {tablo('app_audit_log')}
                (id, username, role_code, device_id, action, detail)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (str(uuid.uuid4()), username, role_code, device_id, action, detail)
            )
            conn.commit()
            cur.close()
        finally:
            try:
                conn.close()
            except Exception:
                pass
    except Exception:
        pass
    return True
